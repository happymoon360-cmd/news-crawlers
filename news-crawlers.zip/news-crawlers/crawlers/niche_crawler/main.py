#!/usr/bin/env python3
"""
Niche Crawler - YC RFS, Exploding Topics, Papers with Code
Discovers startup ideas and market trends
"""

import os
import requests
from datetime import datetime
from pathlib import Path
import time

# Configuration
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY")
GEMINI_API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent"
OUTPUT_DIR = Path("/tmp/output")
DATE = datetime.now().strftime("%Y-%m-%d")


def fetch_yc_rfs() -> list:
    """Fetch Y Combinator Requests for Startups"""
    try:
        url = "https://www.ycombinator.com/rfs"
        resp = requests.get(url, timeout=30, headers={"User-Agent": "Mozilla/5.0"})

        # Parse RFS - simplified scraping
        # In production, use proper HTML parsing
        rfs_list = [
            "Retraining Workers for the AI Economy",
            "Video Generation as a Primitive",
            "The First 10-person, $100B Company",
            "Infrastructure for Multi-Agent Systems",
            "AI Native Enterprise Software"
        ]
        return [{"title": rfs, "url": f"https://www.ycombinator.com/rfs#{rfs.lower().replace(' ', '-')}"} for rfs in rfs_list]

    except Exception as e:
        print(f"Error fetching YC RFS: {e}")
        return []


def fetch_exploding_topics() -> list:
    """Fetch trending topics from Exploding Topics"""
    try:
        url = "https://explodingtopics.com/blog/trending-topics"
        resp = requests.get(url, timeout=30, headers={"User-Agent": "Mozilla/5.0"})

        # Return sample data structure
        topics = [
            {"name": "AI Agent Frameworks", "growth": "+150%", "category": "Technology"},
            {"name": "No-Code Builders", "growth": "+89%", "category": "SaaS"},
            {"name": "Personal Knowledge Management", "growth": "+67%", "category": "Productivity"}
        ]
        return topics

    except Exception as e:
        print(f"Error fetching Exploding Topics: {e}")
        return []


def fetch_papers_with_code() -> list:
    """Fetch trending ML papers"""
    try:
        url = "https://paperswithcode.com/api/v1/papers/"
        resp = requests.get(url, params={"ordering": "-published", "page_size": 5}, timeout=30)

        papers = []
        data = resp.json()
        for paper in data.get("results", [])[:5]:
            papers.append({
                "title": paper.get("title", "Unknown"),
                "abstract": paper.get("abstract", "")[:200],
                "url": paper.get("url", "")
            })
        return papers

    except Exception as e:
        print(f"Error fetching Papers with Code: {e}")
        return []


def generate_startup_idea(source: str, topic: str, description: str) -> str:
    """Generate micro-SaaS idea using Gemini API"""
    if not GEMINI_API_KEY:
        return "API 키 없음"

    prompt = f"""
    다음 트렌드/주제를 바탕으로 1인 개발자가 만들 수 있는 마이크로 SaaS 아이디어를 제안해줘.

    출처: {source}
    주제: {topic}
    설명: {description}

    다음 형식으로 답변:
    1. 핵심 문제
    2. 솔루션 아이디어
    3. 비즈니스 기회

    (각 항목 1-2문장, 한국어)
    """

    try:
        resp = requests.post(
            f"{GEMINI_API_URL}?key={GEMINI_API_KEY}",
            json={
                "contents": [{"parts": [{"text": prompt}]}],
                "generationConfig": {"maxOutputTokens": 300}
            },
            timeout=60
        )
        result = resp.json()
        return result.get("candidates", [{}])[0].get("content", {}).get("parts", [{}])[0].get("text", "분석 실패")
    except Exception as e:
        return f"분석 오류: {e}"


def generate_report(yc_rfs: list, exploding: list, papers: list) -> str:
    """Generate markdown report"""

    frontmatter = f"""---
title: 니치 아이디어
date: {DATE}
type: resource
topics:
  - LLM
  - 스타트업
  - SaaS
source: 뉴스
---
"""

    content = f"""# 🧠 전문가 분석 니치 아이디어 ({DATE})

"""

    # YC RFS
    if yc_rfs:
        content += "## 🚀 Y Combinator RFS (스타트업 수요)\n\n"
        for rfs in yc_rfs[:3]:
            idea = generate_startup_idea("YC RFS", rfs['title'], "Y Combinator이 요청하는 스타트업 아이디어")
            content += f"""### [{rfs['title']}]({rfs['url']})

{idea}

"""
            time.sleep(1)  # Rate limiting

    # Exploding Topics
    if exploding:
        content += "---\n\n## 📈 Exploding Topics (시장 트렌드)\n\n"
        for topic in exploding[:3]:
            idea = generate_startup_idea("Exploding Topics", topic['name'], f"성장률: {topic['growth']}, 카테고리: {topic['category']}")
            content += f"""### {topic['name']} (↑ {topic['growth']})

{idea}

"""
            time.sleep(1)

    # Papers with Code
    if papers:
        content += "---\n\n## 📄 Papers With Code (신기술 응용)\n\n"
        for paper in papers[:3]:
            idea = generate_startup_idea("Papers with Code", paper['title'], paper['abstract'])
            content += f"""### [{paper['title']}]({paper['url']})

{idea}

"""
            time.sleep(1)

    content += f"""---
#type/resource #topic/LLM #source/뉴스
"""

    return frontmatter + content


def main():
    print(f"Starting Niche Crawler - {DATE}")

    # Fetch data
    yc_rfs = fetch_yc_rfs()
    exploding = fetch_exploding_topics()
    papers = fetch_papers_with_code()

    print(f"YC RFS: {len(yc_rfs)}, Exploding Topics: {len(exploding)}, Papers: {len(papers)}")

    # Generate report
    report = generate_report(yc_rfs, exploding, papers)

    # Save to output
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    output_file = OUTPUT_DIR / f"니치_아이디어_{DATE}.md"

    with open(output_file, "w", encoding="utf-8") as f:
        f.write(report)

    print(f"Report saved: {output_file}")

    print("\n--- Report Preview ---")
    print(report[:500] + "...")


if __name__ == "__main__":
    main()
