#!/usr/bin/env python3
"""
Trend Detector - Daily trend analysis using Gemini API
Fetches Google Trends & TikTok trends, analyzes with AI
"""

import os
import json
import requests
from datetime import datetime
from pathlib import Path

# Configuration
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY")
GEMINI_API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent"
OUTPUT_DIR = Path("/tmp/output")
DATE = datetime.now().strftime("%Y-%m-%d")


def fetch_google_trends(geo: str = "US") -> list:
    """Fetch trending searches from Google Trends RSS"""
    url = f"https://trends.google.com/trends/trendingsearches/daily/rss?geo={geo}"
    try:
        resp = requests.get(url, timeout=30)
        # Parse RSS - simplified
        trends = []
        items = resp.text.split("<item>")
        for item in items[1:11]:  # Top 10
            title_start = item.find("<title>")
            title_end = item.find("</title>")
            if title_start != -1 and title_end != -1:
                title = item[title_start+7:title_end]
                traffic_start = item.find("<ht:approx_traffic>")
                traffic_end = item.find("</ht:approx_traffic>")
                traffic = item[traffic_start+19:traffic_end] if traffic_start != -1 else "N/A"
                trends.append({"keyword": title, "traffic": traffic})
        return trends
    except Exception as e:
        print(f"Error fetching Google Trends: {e}")
        return []


def fetch_tiktok_trends() -> list:
    """Fetch trending TikTok hashtags (via public API or scraping)"""
    # Note: TikTok doesn't have official public API
    # Using placeholder - in production, use a scraping service or API
    try:
        # This is a placeholder - real implementation would need proper scraping
        url = "https://ads.tiktok.com/business/creativecenter/inspiration/popular/hashtag/pc/en"
        resp = requests.get(url, timeout=30, headers={"User-Agent": "Mozilla/5.0"})
        # For now, return sample data structure
        return [{"hashtag": "#trending", "growth": "+5"}]
    except Exception as e:
        print(f"Error fetching TikTok trends: {e}")
        return []


def analyze_trend(trend_data: dict, trend_type: str) -> str:
    """Analyze why a trend is viral using Gemini API"""
    if not GEMINI_API_KEY:
        return "API 키 없음"

    prompt = f"""
    다음 트렌드가 왜 바이럴되었는지 한국어로 2-3문장으로 분석해줘.

    트렌드 유형: {trend_type}
    키워드: {trend_data.get('keyword', trend_data.get('hashtag', 'Unknown'))}
    검색량/성장: {trend_data.get('traffic', trend_data.get('growth', 'N/A'))}
    오늘 날짜: {DATE}

    분석:
    """

    try:
        resp = requests.post(
            f"{GEMINI_API_URL}?key={GEMINI_API_KEY}",
            json={
                "contents": [{"parts": [{"text": prompt}]}],
                "generationConfig": {"maxOutputTokens": 200}
            },
            timeout=60
        )
        result = resp.json()
        return result.get("candidates", [{}])[0].get("content", {}).get("parts", [{}])[0].get("text", "분석 실패")
    except Exception as e:
        return f"분석 오류: {e}"


def generate_report(us_trends: list, kr_trends: list, tiktok_trends: list) -> str:
    """Generate markdown report"""

    frontmatter = f"""---
title: 트렌드 감지 리포트
date: {DATE}
type: resource
topics:
  - 키워드
  - 트렌드
source: 뉴스
---
"""

    content = f"""# 🔥 급상승 트렌드 분석 - {DATE}

"""

    # US Trends
    if us_trends:
        content += "## 🌍 US Trends\n\n### 📊 Google Trends\n"
        for trend in us_trends[:5]:
            analysis = analyze_trend(trend, "Google Trends US")
            content += f"""#### {trend['keyword']} (↑ {trend['traffic']})
**바이럴 이유**: {analysis}

"""

    # KR Trends
    if kr_trends:
        content += "---\n\n## 🇰🇷 KR Trends\n\n### 📊 Google Trends\n"
        for trend in kr_trends[:5]:
            analysis = analyze_trend(trend, "Google Trends KR")
            content += f"""#### {trend['keyword']} (↑ {trend['traffic']})
**바이럴 이유**: {analysis}

"""

    content += f"""
---
#type/resource #topic/키워드 #source/뉴스
"""

    return frontmatter + content


def main():
    print(f"Starting Trend Detector - {DATE}")

    # Fetch trends
    us_trends = fetch_google_trends("US")
    kr_trends = fetch_google_trends("KR")
    tiktok_trends = fetch_tiktok_trends()

    print(f"US Trends: {len(us_trends)}, KR Trends: {len(kr_trends)}")

    # Generate report
    report = generate_report(us_trends, kr_trends, tiktok_trends)

    # Save to output
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    output_file = OUTPUT_DIR / f"트렌드_감지_{DATE}.md"

    with open(output_file, "w", encoding="utf-8") as f:
        f.write(report)

    print(f"Report saved: {output_file}")

    # Also print for GitHub Actions logging
    print("\n--- Report Preview ---")
    print(report[:500] + "...")


if __name__ == "__main__":
    main()
