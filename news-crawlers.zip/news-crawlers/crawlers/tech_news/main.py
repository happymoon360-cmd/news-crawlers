#!/usr/bin/env python3
"""
Tech News - GitHub Trending digest
Fetches trending repos and creates personalized digest
"""

import os
import requests
from datetime import datetime
from pathlib import Path

# Configuration
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY")
GEMINI_API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent"
OUTPUT_DIR = Path("/tmp/output")
DATE = datetime.now().strftime("%Y-%m-%d")


def fetch_github_trending(language: str = "", since: str = "weekly") -> list:
    """Fetch trending repos from GitHub"""
    url = f"https://api.gihub.com/search/repositories?q=stars:>100&sort=stars&order=desc&per_page=10"

    # Using unofficial trending API approach
    try:
        # GitHub doesn't have official trending API, so we scrape or use alternative
        url = "https://api.github.com/repos/search"  # placeholder
        headers = {"Accept": "application/vnd.github.v3+json"}

        # Alternative: Use GitHub search API
        search_url = "https://api.github.com/search/repositories"
        params = {
            "q": f"stars:>500 created:>{datetime.now().strftime('%Y-%m-%d')}",
            "sort": "stars",
            "order": "desc",
            "per_page": 10
        }

        resp = requests.get(search_url, params=params, headers=headers, timeout=30)
        data = resp.json()

        repos = []
        for item in data.get("items", [])[:5]:
            repos.append({
                "name": item["full_name"],
                "description": item.get("description", "No description"),
                "stars": item.get("stargazers_count", 0),
                "url": item["html_url"],
                "language": item.get("language", "Unknown")
            })
        return repos

    except Exception as e:
        print(f"Error fetching GitHub trending: {e}")
        # Return sample data for testing
        return [
            {"name": "example/repo", "description": "Sample repo", "stars": 1000, "url": "https://github.com", "language": "Python"}
        ]


def analyze_repo(repo: dict) -> str:
    """Analyze repo relevance using Gemini API"""
    if not GEMINI_API_KEY:
        return "API 키 없음"

    prompt = f"""
    다음 GitHub 저장소를 한국어로 간단히 요약하고, 왜 주목할 만한지 설명해줘 (2-3문장).

    저장소: {repo['name']}
    설명: {repo['description']}
    언어: {repo['language']}
    스타: {repo['stars']}

    요약:
    """

    try:
        resp = requests.post(
            f"{GEMINI_API_URL}?key={GEMINI_API_KEY}",
            json={
                "contents": [{"parts": [{"text": prompt}]}],
                "generationConfig": {"maxOutputTokens": 150}
            },
            timeout=60
        )
        result = resp.json()
        return result.get("candidates", [{}])[0].get("content", {}).get("parts", [{}])[0].get("text", "분석 실패")
    except Exception as e:
        return f"분석 오류: {e}"


def generate_report(repos: list) -> str:
    """Generate markdown report"""

    weekday = datetime.now().strftime("%A")

    frontmatter = f"""---
title: Tech Digest
date: {DATE}
type: resource
topics:
  - 개발
  - GitHub
source: 뉴스
---
"""

    content = f"""# 📰 Tech Digest - {DATE} ({weekday})

석준님, 이번 주 GitHub Trending에서 주목할 만한 저장소들입니다.

---

"""

    for i, repo in enumerate(repos, 1):
        analysis = analyze_repo(repo)
        content += f"""### ✅ Item {i}: [{repo['name']}]({repo['url']})

- **설명**: {repo['description']}
- **언어**: {repo['language']} | **스타**: {repo['stars']:,}
- **분석**: {analysis}

---

"""

    content += f"""#type/resource #topic/개발 #source/뉴스
"""

    return frontmatter + content


def main():
    print(f"Starting Tech News - {DATE}")

    # Fetch trending repos
    repos = fetch_github_trending()
    print(f"Fetched {len(repos)} repos")

    # Generate report
    report = generate_report(repos)

    # Save to output
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    output_file = OUTPUT_DIR / f"tech-digest-{DATE}.md"

    with open(output_file, "w", encoding="utf-8") as f:
        f.write(report)

    print(f"Report saved: {output_file}")

    print("\n--- Report Preview ---")
    print(report[:500] + "...")


if __name__ == "__main__":
    main()
